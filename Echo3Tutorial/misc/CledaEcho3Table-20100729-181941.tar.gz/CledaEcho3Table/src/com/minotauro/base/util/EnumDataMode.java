package com.minotauro.base.util;

public enum EnumDataMode {
  DATABASE, INMEMORY
}

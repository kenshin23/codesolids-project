/*
 * Created on 22/09/2008
 */
package com.minotauro.echo.table.renderer;

import nextapp.echo.app.Color;
import nextapp.echo.app.Component;
import nextapp.echo.app.Insets;
import nextapp.echo.app.Label;
import nextapp.echo.app.layout.GridLayoutData;

import com.minotauro.echo.table.base.CellRenderer;
import com.minotauro.echo.table.base.ETable;

/**
 * @author Demián Gutierrez
 */
public class HeadCellRenderer implements CellRenderer {

  protected GridLayoutData gridLayoutData = new GridLayoutData();

  public HeadCellRenderer() {
    gridLayoutData.setInsets(new Insets(5, 5, 5, 5));
    gridLayoutData.setBackground(Color.PINK);
  }

  // --------------------------------------------------------------------------------

  @Override
  public Component getCellRenderer(ETable table, Object value, int col, int row) {
    Label ret = new Label();

    if (value == null) {
      ret.setText("-");
    } else {
      ret.setText(value.toString());
    }

    return ret;
  }

  // --------------------------------------------------------------------------------

  @Override
  public GridLayoutData getGridLayoutData() {
    return gridLayoutData;
  }
}
